package com.mitadt.mitsoeweather;

class WeatherSample {


    public String TimeStamp,tz;
    public double temp,humidity,soil_moisture,wind_speed;



    public String getTimeStamp() {
        return TimeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        TimeStamp = timeStamp;
    }

    public String getTz() {
        return tz;
    }

    public void setTz(String tz) {
        this.tz = tz;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    public double getHumidity() {
        return humidity;
    }

    public void setHumidity(double humidity) {
        this.humidity = humidity;
    }

    public double getSoil_moisture() {
        return soil_moisture;
    }

    public void setSoil_moisture(double soil_moisture) {
        this.soil_moisture = soil_moisture;
    }

    public double getWind_speed() {
        return wind_speed;
    }

    public void setWind_speed(double wind_speed) {
        this.wind_speed = wind_speed;
    }


    @Override
    public String toString() {
        return "WeatherSample{" +
                "TimeStamp='" + TimeStamp + '\'' +
                ", tz='" + tz + '\'' +
                ", temp=" + temp +
                ", humidity=" + humidity +
                ", soil_moisture=" + soil_moisture +
                ", wind_speed=" + wind_speed +
                '}';
    }
}
