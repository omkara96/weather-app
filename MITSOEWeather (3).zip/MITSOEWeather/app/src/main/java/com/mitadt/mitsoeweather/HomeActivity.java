package com.mitadt.mitsoeweather;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import static android.os.Environment.DIRECTORY_DOWNLOADS;
import static java.lang.Double.parseDouble;

public class HomeActivity extends AppCompatActivity {
    Button btn;

    TextView Tstamp;
    TextView Temp;
    TextView Humid;
    TextView SoilMos;
    TextView WinSpeed;
    TextView war1;
    TextView war2;

    private int request_code=1001;
    String ServerName="ftp://ftp.server name";
    String pass="password";
    String uname= "user";
    String line ="";
    WeatherSample sample;
    InputStream in = null;
    String root = Environment.getExternalStorageDirectory().toString();
    public List<WeatherSample> weatherSamples= new ArrayList<>();
    InputStream myin = null;

    public void getData(View view)
    {
     Tstamp = findViewById(R.id.timeStamp);
     Temp = findViewById(R.id.temp);
     Humid = findViewById(R.id.humidity);
     SoilMos = findViewById(R.id.soilMoisture);
     WinSpeed = findViewById(R.id.windSpeed);
     war1 = findViewById(R.id.warningView);
     war2 = findViewById(R.id.downloadTextView);

     war1.setVisibility(View.INVISIBLE);
     war2.setVisibility(View.INVISIBLE);

        String lastest_time =weatherSamples.get(weatherSamples.size()-1).TimeStamp;
        String latest_temp= String.valueOf(weatherSamples.get(weatherSamples.size()-1).temp);
        String latest_humidity= String.valueOf(weatherSamples.get(weatherSamples.size()-1).humidity);
        String latest_soilMosisture= String.valueOf(weatherSamples.get(weatherSamples.size()-1).soil_moisture);
        String latest_windSpeed= String.valueOf(weatherSamples.get(weatherSamples.size()-1).wind_speed);
        //String latest_soilMoisture=weatherSamples.get(weatherSamples.size()-1).soil_moisture;
        Tstamp.setText("Time: "+lastest_time);
        Temp.setText("Tempreture: "+latest_temp+" Deg. C");
        Humid.setText("Humidity: "+latest_humidity+ " %RH");
        SoilMos.setText("Soil Moisture: "+latest_soilMosisture +" %RH");
        WinSpeed.setText("Wind Speed: " +latest_windSpeed+ " Km/Hr");


    }

    public class ftpDownload extends AsyncTask<String, Void, InputStream> {

        @Override
        protected InputStream doInBackground(String... url) {
            war1 = findViewById(R.id.warningView);
            war1.setVisibility(View.INVISIBLE);

            FTPClient ftpClient = new FTPClient();
            int reply;
            String line = "";



            try {

                ftpClient.connect("ftp.aashaymeasurements.com", 21);
                Log.i("Connected", "Done");
                boolean result = ftpClient.login(uname, pass);
                ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
                BufferedInputStream buffin ;
                String file="";
                ftpClient.enterLocalPassiveMode();

                FTPFile[] files = ftpClient.listFiles();

                for(FTPFile file1 : files)
                {
                    // if(file1.toString() == "MIT_Live10min weather.csv")
                    Log.i(":File is" ,file1.toString() );
                }

                String path = ftpClient.printWorkingDirectory();
                Log.i("PAth is",path);
                OutputStream outstr = null;
                boolean sucess = false;

                try {
                     myin = ftpClient.retrieveFileStream("MIT_Live10min weather.csv");

                    BufferedReader reader = new BufferedReader(

                            new InputStreamReader(myin, Charset.forName("UTF-8"))
                    );

                    try {
                        //Step over headers 1st line
                        reader.readLine();
                        while((line = reader.readLine()) != null)
                        {
                            //Split by ","
                            String[] tokens =line.split(",");

                            //Read the data;
                            sample= new WeatherSample();
                            sample.setTimeStamp(tokens[0]);
                            sample.setTz(tokens[1]);
                            if(tokens.length >=5 && tokens[2].length() > 0 ) {
                                sample.setTemp(parseDouble(tokens[2]));
                            }
                            else
                            {
                                sample.setTemp(0);
                            }
                            sample.setHumidity(parseDouble(tokens[3]));
                            sample.setSoil_moisture(parseDouble(tokens[4]));
                            sample.setWind_speed(parseDouble(tokens[5]));
                            weatherSamples.add(sample);
                            Log.d("MyActivity", "Just Ctreated: "+ sample);
                        }
                    }
                    catch (IOException e)
                    {

                        Log.wtf("MyActivity", "Error reading data on file on line"+line,e);
                        e.printStackTrace();

                    }

                    /********* MEthods to save files in intenal Storage Support below sdk 29 ************
                    outstr = new BufferedOutputStream(new FileOutputStream(root+ "/MIT_Live10min weather.csv"));
                    ftpClient.retrieveFile("/"+ "MIT_Live10min weather.csv", outstr);
                    */

                }catch(IOException e)
                {
                    e.printStackTrace();
                } finally
                {
                    if(outstr != null)
                    {
                        outstr.close();
                    }
                }



                ftpClient.logout();
                ftpClient.disconnect();

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return myin;
        }

        @Override
        protected void onPostExecute(InputStream fileOutputStream) {
            btn = findViewById(R.id.button);
            btn.setVisibility(View.VISIBLE);
            war2 = findViewById(R.id.downloadTextView);
            war2.setVisibility(View.INVISIBLE);
            super.onPostExecute(fileOutputStream);

        }
    }


    /******************************* ON Create Methods ***************************************/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        //custom toolbar setting
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        /******* Run Time Permission Starts *****************/

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
        {
            //Start Run TIme Permission

            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,Manifest.permission.MANAGE_EXTERNAL_STORAGE}, request_code );
        }

        else {

            File CsvData = new File(Environment.getExternalStorageDirectory(),"CsvData");
            if(!CsvData.exists()){
                if(!CsvData.mkdirs()){
                    Log.d("Error dir","Failed To create Directory");
                }
            }
        }

        File CsvData = new File(Environment.getExternalStorageDirectory(),"CsvData");
        if(!CsvData.exists()){
            if(!CsvData.mkdirs()){
                Log.d("Error dir","Failed To create Directory");
            }
        }

        new ftpDownload().execute();

    }
        /******* Run TIme Permisson Ends ****************/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.about:{

                Toast.makeText(this,"About",Toast.LENGTH_SHORT).show();
                Intent aboutPg = new Intent(HomeActivity.this,AboutUsActivity.class);
                startActivity(aboutPg);
                break;
            }

            case R.id.info:{
                Toast.makeText(this,"Info",Toast.LENGTH_SHORT).show();
                break;
            }
            default:{
                Toast.makeText(this,"Error",Toast.LENGTH_SHORT).show();
                break;
            }
        }
        return super.onOptionsItemSelected(item);
    }



    /*********** Grant Permission Method  Starts **************/

    //Permisssion Request For App

    @Override
    public void onRequestPermissionsResult(int request_code, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(request_code, permissions, grantResults) ;

        switch (request_code)
        {
            case 1:{
                if(grantResults.length>0 && grantResults[0]== PackageManager.PERMISSION_GRANTED && grantResults.length>0 && grantResults[1]== PackageManager.PERMISSION_GRANTED)
                {
                    //create access point
                    new ftpDownload().execute();
                    File CsvData = new File(Environment.getExternalStorageDirectory(),"CsvData");
                    if(!CsvData.exists()){
                        if(!CsvData.mkdirs()){
                            Log.d("Error dir","Failed To create Directory");
                        }
                    }

                }
                else{
                    // show a msg to user
                }
            }

        }
    }

    /*********** Grant Permission Method  ENDS **************/
}