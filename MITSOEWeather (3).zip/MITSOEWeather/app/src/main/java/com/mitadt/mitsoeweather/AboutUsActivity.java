package com.mitadt.mitsoeweather;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import java.util.Calendar;

import mehdi.sakout.aboutpage.AboutPage;
import mehdi.sakout.aboutpage.Element;

public class AboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Element adsElement = new Element();
        adsElement.setTitle("MIT ADT Weather App ");
        View aboutPage = new AboutPage(this)
                .isRTL(false)
                .enableDarkMode(false)
                .setImage(R.drawable.ic_launcher_background)
                .setDescription("Weather App MIT ADT University. This app gives all details reated to weather from the station located in MIT University")
                .addItem(new Element().setTitle("Version 1.0 Beta"))
                .addItem(adsElement)
                .addItem(new Element().setTitle("Developed by: Omkar Varma\nFinal Year(B.tech) Dept. of ECE MIT SOE"))
                .addGroup("Contact With us")
                .addEmail("omkarvarma96@gmail.com")
                .addWebsite("www.google.com")
                .addFacebook("facebook.com")
                .addTwitter("www.twitter.com")
                .addItem(getCopyRightsElement())
                .create();
        setContentView(aboutPage);
    }

    Element getCopyRightsElement()
    {
        Element copyRightsElement = new Element();
        final String copyroghts = "All Right Reserved MIT ADT University "+Calendar.getInstance().get(Calendar.YEAR);
        copyRightsElement.setTitle(copyroghts);
        copyRightsElement.setIconDrawable(R.drawable.about_icon_google_play);
        copyRightsElement.setAutoApplyIconTint(true);
        copyRightsElement.setIconTint(mehdi.sakout.aboutpage.R.color.about_item_icon_color);
        copyRightsElement.setIconNightTint(android.R.color.white);
        copyRightsElement.setGravity(Gravity.CENTER);
        copyRightsElement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(AboutUsActivity.this, copyroghts,Toast.LENGTH_SHORT).show();
            }
        });

        return  copyRightsElement;
    }
}
